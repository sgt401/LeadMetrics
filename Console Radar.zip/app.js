// ============================================
// CONSOLE RADAR — App Logic
// March 2026 Game Database
// ============================================

const GAMES = [
  // --- NINTENDO SWITCH 2 MARCH EXCLUSIVES ---
  {
    id: 1,
    title: "Pokémon Pokopia",
    releaseDate: "2026-03-05",
    releaseDateLabel: "Mar 5 — Available Now",
    platforms: ["switch2"],
    exclusive: true,
    tags: ["exclusive", "portable", "creature", "family"],
    desc: "Play as a Ditto and build your own Pokémon paradise. Befriend all kinds of Pokémon, copy their moves, and transform a desolate world into a cozy utopia. Co-op-ready.",
    price: 59.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "First sale likely Holiday 2026",
    score: 9,
    cardColorA: "#e4000f",
    cardColorB: "#f59e0b",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 2,
    title: "Monster Hunter Stories 3: Twisted Reflection",
    releaseDate: "2026-03-13",
    releaseDateLabel: "Mar 13",
    platforms: ["switch2", "ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["creature", "portable"],
    desc: "Turn-based RPG in the Monster Hunter universe. Raise monsties, unlock abilities via Rite of Channeling, swim, climb, and soar through a vibrant open world. Demo available.",
    price: 59.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "~30–60 days: Spring/summer sale likely",
    score: 8,
    cardColorA: "#059669",
    cardColorB: "#0ea5e9",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 3,
    title: "Super Mario Bros. Wonder — Switch 2 Edition + Bellabel Park",
    releaseDate: "2026-03-26",
    releaseDateLabel: "Mar 26",
    platforms: ["switch2"],
    exclusive: true,
    tags: ["exclusive", "portable", "family"],
    desc: "Expanded S2 version of the acclaimed 2D Mario. New Bellabel Park area, new characters including Rosalina, co-op with Co-Star Luma, and multiplayer challenges.",
    price: 59.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Nintendo first-party — unlikely to sale before 2027",
    score: 9,
    cardColorA: "#dc2626",
    cardColorB: "#f59e0b",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 4,
    title: "Blue Prince",
    releaseDate: "2026-03-03",
    releaseDateLabel: "Mar 3 — Available Now",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable", "exclusive"],
    desc: "Genre-defying mystery puzzler set in a manor with shifting rooms. Each run reveals new secrets as you search for the mythical Room 46. Cerebral and atmospheric.",
    price: 29.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Indie — watch for sale around 6–8 weeks",
    score: 8,
    cardColorA: "#4f46e5",
    cardColorB: "#818cf8",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 5,
    title: "FATAL FRAME II: Crimson Butterfly REMAKE",
    releaseDate: "2026-03-12",
    releaseDateLabel: "Mar 12",
    platforms: ["switch2", "ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["portable", "cinematic"],
    desc: "Full remake of the acclaimed Japanese horror classic. Twin sisters Mio and Mayu uncover mysteries of a cursed village, fighting vengeful spirits with the Camera Obscura.",
    price: 49.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "~30 days: expect 20% off by mid-April",
    score: 7,
    cardColorA: "#7c3aed",
    cardColorB: "#1e1b4b",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 6,
    title: "Scott Pilgrim EX",
    releaseDate: "2026-03-03",
    releaseDateLabel: "Mar 3 — Available Now",
    platforms: ["switch2", "switch1", "ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["portable", "family"],
    desc: "Expanded brawler with Scott and Ramona. Brawl through space, time, and Toronto streets — solo or four-player co-op. 8-bit energy meets hyper-melodic rock.",
    price: 29.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Watch Steam/PS Store in 4–6 weeks",
    score: 7,
    cardColorA: "#ec4899",
    cardColorB: "#f59e0b",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 7,
    title: "WWE 2K26",
    releaseDate: "2026-03-13",
    releaseDateLabel: "Mar 13",
    platforms: ["switch2", "ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["portable"],
    desc: "400+ playable wrestlers spanning multiple eras. New match types, expanded MyFACTION, and Universe mode. Alternate history storyline with CM Punk as reigning champion.",
    price: 69.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "2K Sports titles drop 40–50% within 60 days",
    score: 6,
    cardColorA: "#b91c1c",
    cardColorB: "#1f2937",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 8,
    title: "The Midnight Walk",
    releaseDate: "2026-03-26",
    releaseDateLabel: "Mar 26",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable", "cinematic"],
    desc: "Dark fantasy adventure handcrafted from real-life clay. Befriend a mysterious lantern creature and outsmart monsters lurking in the dark. Hauntingly beautiful visuals.",
    price: 24.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Indie — consider if under $15 budget",
    score: 7,
    cardColorA: "#0f172a",
    cardColorB: "#7c3aed",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 9,
    title: "Shadow Tactics: Blades of the Shogun",
    releaseDate: "2026-03-18",
    releaseDateLabel: "Mar 18",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable"],
    desc: "Classic top-down stealth tactics comes to Switch 2. Outsmart your foes as a team of unique specialists in feudal Japan. 10% launch discount — one of the best in its genre.",
    price: 35.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "10% launch discount now — good deal",
    score: 8,
    cardColorA: "#7c3aed",
    cardColorB: "#0f766e",
    source: "https://www.ign.com/articles/all-upcoming-nintendo-switch-2-games"
  },
  {
    id: 10,
    title: "Deadzone: Rogue",
    releaseDate: "2026-03-17",
    releaseDateLabel: "Mar 17",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable", "liveservice"],
    desc: "Roguelite FPS in space — blast machines, forge builds with augments and elemental combos. Solo or co-op. Each run unlocks new abilities for endless replayability.",
    price: 19.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Indie roguelite — watch for sale in 4–6 weeks",
    score: 7,
    cardColorA: "#0369a1",
    cardColorB: "#7c3aed",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 11,
    title: "Mega Man Star Force Legacy Collection",
    releaseDate: "2026-03-27",
    releaseDateLabel: "Mar 27",
    platforms: ["switch1", "switch2"],
    exclusive: false,
    tags: ["portable", "family", "creature"],
    desc: "All seven Mega Man Star Force action RPGs in one package. Newly arranged soundtrack, online grid battles. A perfect portable nostalgia trip — compatible on Switch 2.",
    price: 39.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Collections often go 30–40% off in 3 months",
    score: 7,
    cardColorA: "#0ea5e9",
    cardColorB: "#7c3aed",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  // --- PS5 BIG RELEASES ---
  {
    id: 12,
    title: "Crimson Desert",
    releaseDate: "2026-03-19",
    releaseDateLabel: "Mar 19",
    platforms: ["ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["cinematic"],
    desc: "Long-awaited open-world RPG from Pearl Abyss. Expansive cinematic story of mercenary Macduff in a harsh medieval fantasy world. Stunning PS5 visual showcase.",
    price: 69.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "PS Days of Play (June) — likely 20% off",
    score: 8,
    cardColorA: "#b45309",
    cardColorB: "#7c2d12",
    source: "https://www.gamespot.com/articles/2026-upcoming-games-release-schedule/1100-6534941/"
  },
  {
    id: 13,
    title: "Marathon",
    releaseDate: "2026-03-05",
    releaseDateLabel: "Mar 5",
    platforms: ["ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["cinematic", "liveservice"],
    desc: "Bungie's hyper-stylized extraction-shooter reboot. Drop into Tau Ceti IV with your crew, fight for loot, survive other runners. PS5 console exclusive — rich live-service content planned.",
    price: 39.99,
    subFree: "psplus",
    budgetTier: "sub",
    saleWindow: "Free on PS Plus Extra — don't buy separately",
    score: 8,
    cardColorA: "#dc2626",
    cardColorB: "#1d4ed8",
    source: "https://www.playstation.com/en-us/editorial/most-anticipated-games-coming-to-playstation-this-year/"
  },
  {
    id: 14,
    title: "Ghost of Yotei: Legends",
    releaseDate: "2026-03-10",
    releaseDateLabel: "Mar 10",
    platforms: ["ps5"],
    exclusive: true,
    tags: ["exclusive", "cinematic", "liveservice"],
    desc: "FREE update if you own Ghost of Yotei. Co-op multiplayer mode pits you and friends against supernatural monster versions of the Yotei 6 in the samurai setting.",
    price: 0,
    subFree: "own",
    budgetTier: "free",
    saleWindow: "Free update for existing Ghost of Yotei owners",
    score: 9,
    cardColorA: "#0f766e",
    cardColorB: "#6d28d9",
    source: "https://www.youtube.com/watch?v=QE0TBpO_AHw"
  },
  {
    id: 15,
    title: "Planet of Lana II: Children of the Leaf",
    releaseDate: "2026-03-05",
    releaseDateLabel: "Mar 5",
    platforms: ["ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["cinematic", "family"],
    desc: "Gorgeous cinematic platformer, day one on Game Pass. Lana and Mui return in a sci-fi adventure with clever puzzles and emotional storytelling. Stunningly hand-crafted visuals.",
    price: 24.99,
    subFree: "gamepass",
    budgetTier: "sub",
    saleWindow: "FREE on Xbox Game Pass Day 1 — don't buy",
    score: 8,
    cardColorA: "#0ea5e9",
    cardColorB: "#6d28d9",
    source: "https://news.xbox.com/en-us/2026/03/03/xbox-game-pass-march-2026-wave-1/"
  },
  {
    id: 16,
    title: "MLB The Show 26",
    releaseDate: "2026-03-17",
    releaseDateLabel: "Mar 17",
    platforms: ["switch1", "ps5", "xbox"],
    exclusive: false,
    tags: ["family"],
    desc: "Annual baseball sim. Enhanced Road to the Show, deeper Franchise mode, true-to-life action. Available on Switch (original) as well as PS5 and Xbox.",
    price: 69.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "Sports titles drop quickly — expect sale by May",
    score: 6,
    cardColorA: "#1d4ed8",
    cardColorB: "#dc2626",
    source: "https://www.nintendo.com/us/whatsnew/see-what-games-are-arriving-this-march-2026/"
  },
  {
    id: 17,
    title: "Hollow Knight: Silksong",
    releaseDate: "2026-03-12",
    releaseDateLabel: "Mar 12",
    platforms: ["xbox", "pc", "switch2"],
    exclusive: false,
    tags: ["portable"],
    desc: "The long-awaited sequel to Hollow Knight. Play as Hornet in a vast haunted kingdom filled with silk and song. Day One on Xbox Game Pass. A metroidvania masterpiece-in-waiting.",
    price: 39.99,
    subFree: "gamepass",
    budgetTier: "sub",
    saleWindow: "FREE on Xbox Game Pass Day 1 — don't buy if on Game Pass",
    score: 10,
    cardColorA: "#6d28d9",
    cardColorB: "#0f172a",
    source: "https://news.xbox.com/en-us/2026/03/03/xbox-game-pass-march-2026-wave-1/"
  },
  {
    id: 18,
    title: "Persona 5 Royal",
    releaseDate: "2026-03-17",
    releaseDateLabel: "Mar 17 — PS Plus",
    platforms: ["ps5"],
    exclusive: false,
    tags: ["cinematic"],
    desc: "The definitive JRPG masterpiece joins PS Plus Extra. 100+ hours of stylish dungeon crawling, social simulation, and unforgettable storytelling. This is the one you've been waiting for.",
    price: 0,
    subFree: "psplus",
    budgetTier: "sub",
    saleWindow: "FREE on PS Plus Extra — already included",
    score: 10,
    cardColorA: "#dc2626",
    cardColorB: "#1f2937",
    source: "https://www.ign.com/articles/playstation-plus-game-catalog-leak-reveals-march-additions"
  },
  {
    id: 19,
    title: "Cyberpunk 2077",
    releaseDate: "2026-03-10",
    releaseDateLabel: "Mar 10 — Game Pass",
    platforms: ["xbox", "pc"],
    exclusive: false,
    tags: ["cinematic", "liveservice"],
    desc: "V's story in Night City — now on Xbox Game Pass. Massive open-world RPG, deep character builds, Phantom Liberty expansion. One of the best stories in recent gaming.",
    price: 0,
    subFree: "gamepass",
    budgetTier: "sub",
    saleWindow: "FREE on Xbox Game Pass — already included",
    score: 9,
    cardColorA: "#f59e0b",
    cardColorB: "#0f172a",
    source: "https://news.xbox.com/en-us/2026/03/03/xbox-game-pass-march-2026-wave-1/"
  },
  {
    id: 20,
    title: "Kingdom Come: Deliverance II",
    releaseDate: "2026-03-03",
    releaseDateLabel: "Mar 3 — Game Pass",
    platforms: ["xbox", "pc"],
    exclusive: false,
    tags: ["cinematic"],
    desc: "Highly acclaimed historical RPG — day one on Game Pass. Medieval Bohemia in stunning detail, first-person combat, deeply immersive roleplaying. 2025 Game of the Year contender.",
    price: 0,
    subFree: "gamepass",
    budgetTier: "sub",
    saleWindow: "FREE on Xbox Game Pass — already included",
    score: 9,
    cardColorA: "#92400e",
    cardColorB: "#1f2937",
    source: "https://news.xbox.com/en-us/2026/03/03/xbox-game-pass-march-2026-wave-1/"
  },
  // --- MULTIPLATFORM MARCH RELEASES ---
  {
    id: 21,
    title: "Warhammer 40K: Space Marine 2",
    releaseDate: "2026-03-17",
    releaseDateLabel: "Mar 17 — PS Plus",
    platforms: ["ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["cinematic", "liveservice"],
    desc: "Third-person co-op action spectacle. Play as Ultramarine Titus battling the Tyranid horde. Cinematic scale, brutal combat, and excellent 3-player co-op. Free on PS Plus Extra.",
    price: 0,
    subFree: "psplus",
    budgetTier: "sub",
    saleWindow: "FREE on PS Plus Extra March",
    score: 8,
    cardColorA: "#1d4ed8",
    cardColorB: "#f59e0b",
    source: "https://www.ign.com/articles/playstation-plus-game-catalog-leak-reveals-march-additions"
  },
  {
    id: 22,
    title: "007 First Light",
    releaseDate: "2026-03-27",
    releaseDateLabel: "Mar 27",
    platforms: ["switch2", "ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["cinematic", "portable"],
    desc: "New James Bond origin story across all major platforms. Espionage, gadgets, and cinematic action — a rare multiplatform event title. Watch for this one.",
    price: 69.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "Wait 4–6 weeks for a quick discount",
    score: 8,
    cardColorA: "#475569",
    cardColorB: "#f59e0b",
    source: "https://www.ign.com/articles/video-game-release-dates-ps4-ps5-xbox-one-series-x-nintendo-switch"
  },
  {
    id: 23,
    title: "Dynasty Warriors 3: Complete Edition Remastered",
    releaseDate: "2026-03-19",
    releaseDateLabel: "Mar 19",
    platforms: ["switch2", "switch1", "ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["portable", "family"],
    desc: "The definitive remaster of a beloved hack-and-slash classic. Hundreds of enemy armies, iconic officers, and all modes in one package. Great for co-op sessions.",
    price: 49.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "Koei titles typically go 30% off within 60 days",
    score: 6,
    cardColorA: "#dc2626",
    cardColorB: "#f59e0b",
    source: "https://www.gamespot.com/articles/2026-upcoming-games-release-schedule/1100-6534941/"
  },
  {
    id: 24,
    title: "Mouse: P.I. for Hire",
    releaseDate: "2026-03-19",
    releaseDateLabel: "Mar 19",
    platforms: ["switch2", "switch1", "ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["portable", "family"],
    desc: "Charming noir-themed puzzle adventure starring a mouse detective. Family-friendly art style, clever puzzles, great for all ages. Available across all platforms.",
    price: 19.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Indie — consider at $15 or below",
    score: 7,
    cardColorA: "#92400e",
    cardColorB: "#1f2937",
    source: "https://www.gamespot.com/articles/2026-upcoming-games-release-schedule/1100-6534941/"
  },
  {
    id: 25,
    title: "Roblox",
    releaseDate: "ongoing",
    releaseDateLabel: "Free — Ongoing",
    platforms: ["switch1", "ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["liveservice", "family"],
    desc: "The ultimate live-service rabbit hole. Thousands of user-created games, constant updates, Robux economy. Free to play — in-app purchases for Robux. Available across all platforms.",
    price: 0,
    subFree: "free",
    budgetTier: "free",
    saleWindow: "Free to download — Robux packs for cosmetics",
    score: 8,
    cardColorA: "#dc2626",
    cardColorB: "#1f2937",
    source: "https://www.roblox.com/"
  },
  {
    id: 26,
    title: "Disney Dreamlight Valley — Switch 2 Edition",
    releaseDate: "2026-03-25",
    releaseDateLabel: "Mar 25",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable", "family", "creature", "liveservice"],
    desc: "Upgraded S2 version with improved performance, enhanced graphics, and increased object limit. Cozy life sim meets Disney magic — ideal family-friendly portable experience.",
    price: 39.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Gameloft — check for bundle deals",
    score: 7,
    cardColorA: "#0ea5e9",
    cardColorB: "#f59e0b",
    source: "https://www.nintendo.com/us/whatsnew/latest-nintendo-direct-partner-showcase-features-new-and-classic-titles-coming-to-nintendo-switch-2-and-nintendo-switch/"
  },
  // --- NINTENDO DIRECT HIGHLIGHTS ---
  {
    id: 27,
    title: "The Duskbloods",
    releaseDate: "2026 TBA",
    releaseDateLabel: "2026 — TBA",
    platforms: ["switch2"],
    exclusive: true,
    tags: ["exclusive"],
    desc: "FromSoftware's Nintendo Switch 2 exclusive — a dark, atmospheric action RPG. Announced at Nintendo Direct. If you own a Switch 2, this is the exclusive to watch for.",
    price: 59.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "No release date yet — wishlist it",
    score: 9,
    cardColorA: "#1c1917",
    cardColorB: "#7c3aed",
    source: "https://www.ign.com/articles/video-game-release-dates-ps4-ps5-xbox-one-series-x-nintendo-switch"
  },
  {
    id: 28,
    title: "Elden Ring: Tarnished Edition",
    releaseDate: "2026 TBA",
    releaseDateLabel: "2026 — TBA",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["exclusive", "portable", "cinematic"],
    desc: "The definitive Elden Ring arrives on Switch 2 — complete edition with all DLC. Play one of the greatest open-world RPGs ever made in portable form. Massive get for Switch 2 owners.",
    price: 59.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "No exact date — keep an eye on Nintendo eShop",
    score: 10,
    cardColorA: "#b45309",
    cardColorB: "#1c1917",
    source: "https://www.ign.com/articles/video-game-release-dates-ps4-ps5-xbox-one-series-x-nintendo-switch"
  },
  {
    id: 29,
    title: "Indiana Jones and the Great Circle",
    releaseDate: "2026 TBA",
    releaseDateLabel: "2026 — Switch 2 TBA",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable", "cinematic"],
    desc: "MachineGames' acclaimed Indiana Jones adventure comes to Switch 2. First-person action-adventure set between Raiders and Temple of Doom. Already loved on Xbox/PC.",
    price: 49.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "Switch 2 version TBA — it's on Game Pass for Xbox/PC",
    score: 8,
    cardColorA: "#92400e",
    cardColorB: "#f59e0b",
    source: "https://www.nintendo.com/us/whatsnew/latest-nintendo-direct-partner-showcase-features-new-and-classic-titles-coming-to-nintendo-switch-2-and-nintendo-switch/"
  },
  {
    id: 30,
    title: "Fallout 4: Anniversary Edition",
    releaseDate: "2026 TBA",
    releaseDateLabel: "2026 — Switch 2 TBA",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable", "cinematic", "liveservice"],
    desc: "Complete Fallout 4 with all DLC comes to Switch 2. Explore the Commonwealth wasteland on the go — a massive RPG rabbit hole with hundreds of hours of content.",
    price: 39.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "Switch 2 date TBA — Bethesda titles often hit sales quickly",
    score: 8,
    cardColorA: "#4d7c0f",
    cardColorB: "#1c1917",
    source: "https://www.nintendo.com/us/whatsnew/latest-nintendo-direct-partner-showcase-features-new-and-classic-titles-coming-to-nintendo-switch-2-and-nintendo-switch/"
  },
  {
    id: 31,
    title: "The Elder Scrolls IV: Oblivion Remastered",
    releaseDate: "2026 TBA",
    releaseDateLabel: "2026 — Switch 2 TBA",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable", "cinematic"],
    desc: "Bethesda's beloved RPG rebuilt from scratch for Switch 2. All story expansions (Shivering Isles, Knights of the Nine) included. One of the most anticipated Switch 2 ports.",
    price: 49.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "Physical + digital — watch at launch for bundle deals",
    score: 9,
    cardColorA: "#b45309",
    cardColorB: "#4d7c0f",
    source: "https://www.nintendo.com/us/whatsnew/latest-nintendo-direct-partner-showcase-features-new-and-classic-titles-coming-to-nintendo-switch-2-and-nintendo-switch/"
  },
  {
    id: 32,
    title: "FINAL FANTASY VII REBIRTH",
    releaseDate: "2026-06-03",
    releaseDateLabel: "Jun 3 — Switch 2",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable", "cinematic"],
    desc: "The sprawling JRPG epic comes to Switch 2 on June 3. Ride Chocobos, explore vast plains, and continue Cloud Strife's story in portable form. A genre-defining experience.",
    price: 59.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "June 3 launch — pre-order bonuses available on eShop",
    score: 9,
    cardColorA: "#0ea5e9",
    cardColorB: "#1c1917",
    source: "https://www.nintendo.com/us/whatsnew/latest-nintendo-direct-partner-showcase-features-new-and-classic-titles-coming-to-nintendo-switch-2-and-nintendo-switch/"
  },
  {
    id: 33,
    title: "Saros",
    releaseDate: "2026-04-30",
    releaseDateLabel: "Apr 30 — PS5 Exclusive",
    platforms: ["ps5"],
    exclusive: true,
    tags: ["exclusive", "cinematic"],
    desc: "New PS5 exclusive. Dark atmospheric action set in a world trapped in a recurring apocalyptic cycle. Visually stunning — justifies the PS5 purchase.",
    price: 69.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "PS5 exclusive — unlikely to sale before Fall 2026",
    score: 8,
    cardColorA: "#1e3a5f",
    cardColorB: "#7c3aed",
    source: "https://www.gamespot.com/articles/2026-upcoming-games-release-schedule/1100-6534941/"
  },
  {
    id: 34,
    title: "Marvel's Wolverine",
    releaseDate: "2026 TBA",
    releaseDateLabel: "2026 — PS5 Exclusive",
    platforms: ["ps5"],
    exclusive: true,
    tags: ["exclusive", "cinematic"],
    desc: "Insomniac's PS5 exclusive starring Logan. Ferocious combat, action-packed set pieces, single-player story. The crown jewel of PS5's 2026 exclusive lineup from the Spider-Man team.",
    price: 69.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Insomniac PS5 exclusive — buy at launch",
    score: 10,
    cardColorA: "#dc2626",
    cardColorB: "#f59e0b",
    source: "https://www.playstation.com/en-us/editorial/most-anticipated-games-coming-to-playstation-this-year/"
  },
  {
    id: 35,
    title: "Hollow Knight: Silksong (Switch 2)",
    releaseDate: "2026-03-12",
    releaseDateLabel: "Mar 12",
    platforms: ["switch2"],
    exclusive: false,
    tags: ["portable"],
    desc: "Hornet's adventure — coming to Switch 2 via Game Pass Premium / direct purchase. One of the most anticipated sequels in gaming. Play as Hornet in a vast haunted kingdom.",
    price: 39.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Also on Game Pass if you have Xbox/PC — check your subs",
    score: 10,
    cardColorA: "#6d28d9",
    cardColorB: "#0f172a",
    source: "https://news.xbox.com/en-us/2026/03/03/xbox-game-pass-march-2026-wave-1/"
  },
  {
    id: 36,
    title: "Pokémon XD: Gale of Darkness",
    releaseDate: "2026-03-TBD",
    releaseDateLabel: "Mar — NSO Expansion Pack",
    platforms: ["switch1", "switch2"],
    exclusive: false,
    tags: ["portable", "creature", "family"],
    desc: "Free for NSO Expansion Pack subscribers! The beloved GameCube Pokémon RPG — snag Shadow Pokémon and purify them. A rare portable classic that needs a subscription to play.",
    price: 0,
    subFree: "nso",
    budgetTier: "sub",
    saleWindow: "FREE with NSO Expansion Pack ($49.99/yr)",
    score: 8,
    cardColorA: "#7c3aed",
    cardColorB: "#0ea5e9",
    source: "https://comicbook.com/gaming/news/nintendo-switch-online-games-new-march-2026/"
  },
  {
    id: 37,
    title: "Death Stranding 2: On the Beach (PC)",
    releaseDate: "2026-03-TBD",
    releaseDateLabel: "Mar — PC",
    platforms: ["pc"],
    exclusive: false,
    tags: ["cinematic"],
    desc: "Hideo Kojima's sequel arrives on PC. Deliver packages across a post-apocalyptic America — bizarre, cinematic, and impossible to stop thinking about. A true PS5 justifier now on PC too.",
    price: 69.99,
    subFree: null,
    budgetTier: "buy",
    saleWindow: "Already out on PS5 — PC version launches this month",
    score: 8,
    cardColorA: "#475569",
    cardColorB: "#0f172a",
    source: "https://www.youtube.com/watch?v=QE0TBpO_AHw"
  },
  {
    id: 38,
    title: "Diablo IV: Lord of Hatred",
    releaseDate: "2026-04-28",
    releaseDateLabel: "Apr 28 — All Platforms",
    platforms: ["ps5", "xbox", "pc"],
    exclusive: false,
    tags: ["liveservice", "cinematic"],
    desc: "Major expansion for Diablo IV launching late April. New region, new villain, extensive endgame content. If you're in the Diablo IV ecosystem, this is the next big update.",
    price: 39.99,
    subFree: null,
    budgetTier: "wait",
    saleWindow: "Blizzard expansions — watch for bundle at launch",
    score: 8,
    cardColorA: "#7c2d12",
    cardColorB: "#1c1917",
    source: "https://www.gamespot.com/articles/2026-upcoming-games-release-schedule/1100-6534941/"
  }
];

// ============================================
// STATE
// ============================================
let activeMode = "all";
let activePlatform = "all";
let activeSort = "date";
let userHardware = ["switch2", "ps5", "pc"];
let userSubs = ["psplus"];
let userBudget = 70;
let budgetModeActive = false;

// ============================================
// INIT
// ============================================
document.addEventListener("DOMContentLoaded", () => {
  initTheme();
  initControls();
  renderGames();
});

// ============================================
// THEME
// ============================================
function initTheme() {
  const toggle = document.querySelector("[data-theme-toggle]");
  const root = document.documentElement;
  let dark = matchMedia("(prefers-color-scheme: dark)").matches;
  root.setAttribute("data-theme", dark ? "dark" : "light");
  updateToggleIcon(toggle, dark);

  toggle.addEventListener("click", () => {
    dark = !dark;
    root.setAttribute("data-theme", dark ? "dark" : "light");
    updateToggleIcon(toggle, dark);
  });
}

function updateToggleIcon(btn, isDark) {
  btn.innerHTML = isDark
    ? `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>`
    : `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;
  btn.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
}

// ============================================
// CONTROLS
// ============================================
function initControls() {
  // Mode buttons
  document.querySelectorAll(".mode-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".mode-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      activeMode = btn.dataset.mode;
      renderGames();
    });
  });

  // Platform buttons
  document.querySelectorAll(".pf-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".pf-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      activePlatform = btn.dataset.platform;
      renderGames();
    });
  });

  // Sort
  document.getElementById("sortSelect").addEventListener("change", e => {
    activeSort = e.target.value;
    renderGames();
  });

  // Budget slider
  const slider = document.getElementById("budgetRange");
  const val = document.getElementById("budgetVal");
  slider.addEventListener("input", () => {
    const v = parseInt(slider.value);
    val.textContent = v === 0 ? "Free only" : v >= 70 ? "Any" : `$${v}`;
  });

  // Apply Budget
  document.getElementById("applyBudget").addEventListener("click", () => {
    userHardware = [...document.querySelectorAll("input[name=hw]:checked")].map(i => i.value);
    userSubs = [...document.querySelectorAll("input[name=sub]:checked")].map(i => i.value);
    userBudget = parseInt(document.getElementById("budgetRange").value);
    budgetModeActive = true;
    renderGames();
    const btn = document.getElementById("applyBudget");
    btn.textContent = "✓ Budget Mode Active";
    btn.style.background = "#16a34a";
    setTimeout(() => {
      btn.textContent = "Apply Budget Mode";
      btn.style.background = "";
    }, 2000);
  });
}

// ============================================
// FILTER & SORT
// ============================================
function filterGames() {
  return GAMES.filter(game => {
    // Platform filter
    if (activePlatform !== "all" && !game.platforms.includes(activePlatform)) return false;

    // Mode filter
    if (activeMode === "exclusive" && !game.exclusive) return false;
    if (activeMode === "portable" && !game.tags.includes("portable")) return false;
    if (activeMode === "creature" && !game.tags.includes("creature")) return false;
    if (activeMode === "family" && !game.tags.includes("family")) return false;
    if (activeMode === "liveservice" && !game.tags.includes("liveservice")) return false;
    if (activeMode === "cinematic" && !game.tags.includes("cinematic")) return false;

    return true;
  });
}

function sortGames(games) {
  return [...games].sort((a, b) => {
    if (activeSort === "date") {
      const da = a.releaseDate === "ongoing" ? "2020-01-01" : a.releaseDate;
      const db = b.releaseDate === "ongoing" ? "2020-01-01" : b.releaseDate;
      return new Date(da) - new Date(db);
    }
    if (activeSort === "name") return a.title.localeCompare(b.title);
    if (activeSort === "rating") return b.score - a.score;
    if (activeSort === "budget") {
      // Free first, then sub, then lowest price
      const scoreA = getBudgetPriority(a);
      const scoreB = getBudgetPriority(b);
      return scoreA - scoreB;
    }
    return 0;
  });
}

function getBudgetPriority(game) {
  if (game.price === 0 && game.subFree === "free") return 0;
  if (game.subFree === "own") return 1;
  if (budgetModeActive && game.subFree && userSubs.includes(game.subFree)) return 2;
  return game.price;
}

// ============================================
// RENDER
// ============================================
function renderGames() {
  const grid = document.getElementById("gameGrid");
  const noResults = document.getElementById("noResults");
  const countEl = document.getElementById("resultsCount");

  const filtered = filterGames();
  const sorted = sortGames(filtered);

  countEl.textContent = `Showing ${filtered.length} game${filtered.length !== 1 ? "s" : ""}`;

  if (filtered.length === 0) {
    grid.innerHTML = "";
    noResults.style.display = "block";
    return;
  }
  noResults.style.display = "none";

  grid.innerHTML = sorted.map(game => renderCard(game)).join("");
}

function getScoreStyle(score) {
  if (score >= 9) return { bg: "rgba(22,163,74,0.15)", color: "#16a34a" };
  if (score >= 7) return { bg: "rgba(234,179,8,0.15)", color: "#ca8a04" };
  return { bg: "rgba(148,163,184,0.15)", color: "#64748b" };
}

function renderCard(game) {
  // Determine if dimmed by budget mode
  let dimmed = false;
  let budgetAdviceText = "";
  let priceClass = "price-paid";
  let priceText = game.price === 0 ? "Free" : `$${game.price.toFixed(2)}`;

  if (budgetModeActive) {
    // Check hardware ownership
    const platformsOwned = game.platforms.some(p => {
      if (p === "switch2") return userHardware.includes("switch2");
      if (p === "switch1") return userHardware.includes("switch1") || userHardware.includes("switch2");
      if (p === "ps5") return userHardware.includes("ps5");
      if (p === "xbox") return userHardware.includes("xbox");
      if (p === "pc") return userHardware.includes("pc");
      return false;
    });

    // Check sub coverage
    const isSubFree = game.subFree && (
      (game.subFree === "psplus" && userSubs.includes("psplus")) ||
      (game.subFree === "gamepass" && userSubs.includes("gamepass")) ||
      (game.subFree === "nso" && userSubs.includes("nso")) ||
      (game.subFree === "free")
    );

    const withinBudget = game.price <= userBudget;

    if (game.subFree === "own") {
      priceClass = "price-free";
      priceText = "Free if you own it";
      budgetAdviceText = "Already included";
    } else if (isSubFree) {
      priceClass = "price-sub";
      priceText = "Included in sub";
      budgetAdviceText = "Already paying for it";
    } else if (game.price === 0) {
      priceClass = "price-free";
      priceText = "Free";
      budgetAdviceText = "No cost";
    } else if (!withinBudget) {
      dimmed = true;
      priceClass = "price-wait";
      priceText = `$${game.price.toFixed(2)}`;
      budgetAdviceText = "Over budget — wait for sale";
    } else {
      budgetAdviceText = game.saleWindow;
    }

    if (!platformsOwned) {
      dimmed = true;
      budgetAdviceText = "No hardware yet";
    }
  } else {
    if (game.subFree === "psplus" || game.subFree === "gamepass" || game.subFree === "nso") {
      priceClass = "price-sub";
      priceText = game.subFree === "psplus" ? "PS Plus" : game.subFree === "gamepass" ? "Game Pass" : "NSO";
    } else if (game.price === 0) {
      priceClass = "price-free";
      priceText = "Free";
    } else if (game.subFree === "own") {
      priceClass = "price-free";
      priceText = "Free update";
    }
    budgetAdviceText = game.saleWindow;
  }

  const ss = getScoreStyle(game.score);

  // Platform badges
  const platformBadges = game.platforms.slice(0, 4).map(p => {
    const labels = { switch2: "S2", switch1: "S1", ps5: "PS5", xbox: "Xbox", pc: "PC" };
    return `<span class="platform-badge pb-${p}">${labels[p] || p}</span>`;
  }).join("");

  // Tags
  const tagMap = {
    exclusive: "⭐ Exclusive",
    portable: "🎮 Portable",
    creature: "🐾 Creature",
    family: "👨‍👩‍👧 Family",
    liveservice: "🔄 Live Service",
    cinematic: "🎬 Cinematic"
  };
  const tagBadges = game.tags.map(t =>
    `<span class="tag tag-${t}">${tagMap[t] || t}</span>`
  ).join("");

  // Sub tag
  let subTag = "";
  if (game.subFree === "psplus") subTag = `<span class="tag tag-free">PS Plus</span>`;
  else if (game.subFree === "gamepass") subTag = `<span class="tag tag-free">Game Pass</span>`;
  else if (game.subFree === "nso") subTag = `<span class="tag tag-free">NSO Free</span>`;
  else if (game.subFree === "free") subTag = `<span class="tag tag-free">Free</span>`;
  else if (game.subFree === "own") subTag = `<span class="tag tag-free">Free Update</span>`;

  return `
    <article class="game-card${dimmed ? " dimmed" : ""}" 
             style="--card-color-a: ${game.cardColorA}; --card-color-b: ${game.cardColorB};"
             data-id="${game.id}">
      <div class="card-art"></div>
      <div class="card-body">
        <div class="card-header-row">
          <h3 class="card-title">${game.title}</h3>
          <div class="card-score" style="--score-bg: ${ss.bg}; --score-color: ${ss.color};">${game.score}</div>
        </div>
        <div class="card-meta">
          <span class="release-date">📅 ${game.releaseDateLabel}</span>
          <div class="platform-badges">${platformBadges}</div>
        </div>
        <p class="card-desc">${game.desc}</p>
        <div class="card-tags">${tagBadges}${subTag}</div>
        <div class="card-budget-row">
          <span class="price-tag ${priceClass}">${priceText}</span>
          <span class="budget-advice">${budgetAdviceText}</span>
        </div>
      </div>
    </article>
  `;
}
